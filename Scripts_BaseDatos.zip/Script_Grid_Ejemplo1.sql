CREATE DATABASE GridSample
GO
USE GridSample
GO
CREATE TABLE Producto (
	IdProducto BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL
	,Descripcion VARCHAR(200)
	,IdPresentacion BIGINT
	,Precio DECIMAL(20,4)
	,FechaRegistro DATETIME DEFAULT GETDATE()
)
GO
CREATE TABLE Presentacion (
	IdPresentacion BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL
	,Descripcion VARCHAR(200)
	,FechaRegistro DATETIME DEFAULT GETDATE()
)
GO
CREATE TABLE Movimiento (
	IdMovimiento BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL
	,Descripcion VARCHAR(200)
	,idProducto BIGINT
	,Cantidad INT
	,InOut	BIT
	,FechaMovimiento DATETIME DEFAULT GETDATE()
)
GO
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('AEROLEP', 1, 100.50)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('5 XZR 500', 2, 120.80)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('5 XZR 500', 3, 80.20)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('ENTINARAP', 4, 400.20)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('ENTINARAP', 5, 486.80)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('ENTINARAP', 6, 501.30)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('ENTINARAP', 7, 520.00)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('ONCEGLUTI 300', 8, 40.70)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('ONCEGLUTI 300', 9, 45.16)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('ONCEGLUTI 300', 10, 52.40)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('ONCEGLUTI XR', 11, 70.20)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('ONCEGLUTI XR', 12, 78.50)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('VITCIRCU', 13, 300.20)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('VITCIRCU', 14, 340.56)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('VITCIRCU', 15, 360.12)
INSERT INTO Producto (Descripcion, idPresentacion, Precio) VALUES ('VITCIRCU', 16, 389.99)
GO
INSERT INTO Presentacion (Descripcion) VALUES ('aer.inhal.c/adap.x 250ds')
INSERT INTO Presentacion (Descripcion) VALUES ('500 mg comp.x 100')
INSERT INTO Presentacion (Descripcion) VALUES ('500 mg comp.x 50')
INSERT INTO Presentacion (Descripcion) VALUES ('100 mg c�ps.x 30')
INSERT INTO Presentacion (Descripcion) VALUES ('300 mg c�ps.x 30')
INSERT INTO Presentacion (Descripcion) VALUES ('300 mg c�ps.x 60')
INSERT INTO Presentacion (Descripcion) VALUES ('600 mg comp.x 30')

INSERT INTO Presentacion (Descripcion) VALUES ('tab.x 20')
INSERT INTO Presentacion (Descripcion) VALUES ('tab.x 50')
INSERT INTO Presentacion (Descripcion) VALUES ('tab.x 90')
INSERT INTO Presentacion (Descripcion) VALUES ('comp.x 30')
INSERT INTO Presentacion (Descripcion) VALUES ('comp.x 60')

INSERT INTO Presentacion (Descripcion) VALUES ('2 mg comp.x 20')
INSERT INTO Presentacion (Descripcion) VALUES ('2 mg comp.x 50')
INSERT INTO Presentacion (Descripcion) VALUES ('5 mg comp.x 20')
INSERT INTO Presentacion (Descripcion) VALUES ('5 mg comp.x 50')
GO
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 1, 2, 0, '2020-02-01 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA PRIVADA', 2, 1, 0, '2020-03-12 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('COMPRA PROVEEDOR', 2, 4, 1, '2020-22-05 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 5, 1, 0, '2020-06-12 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 3, 7, 0, '2020-18-09 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 8, 4, 0, '2020-04-07 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA PRIVADA', 4, 14, 0, '2020-02-12 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 12, 2, 0, '2020-28-06 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 13, 3, 0, '2020-31-05 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA PRIVADA', 14, 22, 0, '2020-03-01 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 14, 1, 0, '2020-02-12 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 15, 6, 0, '2020-13-01 08:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 15, 4, 0, '2020-08-09 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 15, 2, 0, '2020-28-06 14:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 16, 4, 0, '2020-04-11 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('COMPRA PROVEEDOR', 5, 18, 1, '2020-02-01 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('COMPRA PROVEEDOR', 6, 27, 1, '2020-03-12 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('COMPRA PROVEEDOR', 7, 42, 1, '2020-10-01 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 9, 1, 0, '2020-06-01 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('VENTA P�BLICO', 10, 6, 0, '2020-02-01 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('COMPRA PROVEEDOR', 16, 14, 1, '2020-07-09 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('COMPRA PROVEEDOR', 11, 26, 1, '2020-05-07 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('COMPRA PROVEEDOR', 11, 8, 1, '2020-21-06 01:43:47.430')
INSERT INTO Movimiento (Descripcion, idProducto, Cantidad, InOut, FechaMovimiento) VALUES ('COMPRA PROVEEDOR', 11, 10, 1, '2020-05-11 01:43:47.430')

