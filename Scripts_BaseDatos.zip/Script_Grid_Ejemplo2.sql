--Ejemplo de algunos selects utilizados dentro dle proyecto.
SELECT 
	A.IdProducto
	,A.Descripcion 
	--,B.IdPresentacion
	--,B.Descripcion
	--,A.FechaRegistro
FROM Producto AS A
INNER JOIN Presentacion AS B
      ON A.idPresentacion = B.IdPresentacion
WHERE 1 = 1

SELECT 
	A.IdMovimiento
	,A.Descripcion Movimiento
	,CASE WHEN A.InOut = 0 THEN 'VENTA' ELSE 'COMPRA' END [Tipo Movimiento]
	,A.Cantidad	
	,CONVERT(DATE,A.FechaMovimiento) AS [Fecha Movimiento]
FROM Movimiento AS A
WHERE 1 = 1

SELECT * FROM Movimiento

SELECT 
	A.IdMovimiento
	,A.Descripcion Movimiento
	,CASE WHEN A.InOut = 0 THEN 'VENTA' ELSE 'COMPRA' END [Tipo Movimiento]
	,A.Cantidad	
	,CONVERT(DATE,A.FechaMovimiento) AS [Fecha Movimiento]
	,B.Descripcion AS Producto
	,B.Precio AS PrecioUnitario
	,B.Precio * A.Cantidad AS PrecioTotal
	,C.Descripcion AS Presentacion
FROM Movimiento AS A
INNER JOIN Producto AS B
	  ON A.idProducto = B.IdProducto
INNER JOIN Presentacion AS C
      ON B.IdPresentacion = C.IdPresentacion
WHERE (A.IdMovimiento = 3)